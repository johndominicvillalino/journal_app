import { Controller } from "@hotwired/stimulus";
import "jquery";

export default class extends Controller {
  connect() {
    
  }
};
